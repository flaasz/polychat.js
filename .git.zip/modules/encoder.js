const protobuf = require("protobufjs");


module.exports = {
    encodeMessage: async function (clients, encodedMessage) {
        protobuf.load("./protos/polychat.proto", function (err, root) {
            if (err)
                throw err;

            let newMessage = {
                serverId: '[Discord]',
                message: encodedMessage,
                messageOffset: encodedMessage.length
            };

            var type = root.lookupType("polychat.ChatMessage");

            var payload = type.create(newMessage);

            //console.log(newMessage);

            var buffer = type.encode(payload).finish();

            protobuf.load("./protos/any.proto", function (err, root) {
                if (err)
                    throw err;

                let encodedMessage = {
                    typeUrl: 'type.googleapis.com/polychat.ChatMessage',
                    value: buffer
                };

                //console.log(encodedMessage);

                var anytype = root.lookupType("google.protobuf.Any");

                var encodedPayload = anytype.create(encodedMessage);

                var data = anytype.encode(encodedPayload).finish();

                //console.log(anytype.decode(data));
                //console.log(data.length);


                var datalen = new Buffer.alloc(4);
                datalen.writeUInt32BE(data.length, 0);

                data = Buffer.concat([datalen, data]);



                //console.log("datalen: ",data);



                return clients.forEach(function (client) {
                    client.write(data);
                });

            });



        });

    },
    encodeCommand: async function (client, encodedCommand) {
        protobuf.load("./protos/polychat.proto", function (err, root) {
            if (err)
                throw err;

            let newCommand = {
                args: encodedCommand.command,
                discordChannelId: encodedCommand.interactionId,
                discordCommandName: 'exec',
                defaultCommand: '$args'
            };

            var type = root.lookupType("polychat.GenericCommand");

            var payload = type.create(newCommand);

            console.log(newCommand);

            var buffer = type.encode(payload).finish();

            protobuf.load("./protos/any.proto", function (err, root) {
                if (err)
                    throw err;

                let encodedCommand = {
                    typeUrl: 'type.googleapis.com/polychat.GenericCommand',
                    value: buffer
                };

                //console.log(encodedMessage);

                var anytype = root.lookupType("google.protobuf.Any");

                var encodedPayload = anytype.create(encodedCommand);

                var data = anytype.encode(encodedPayload).finish();

                console.log(anytype.decode(data));
                //console.log(data.length);


                var datalen = new Buffer.alloc(4);
                datalen.writeUInt32BE(data.length, 0);

                data = Buffer.concat([datalen, data]);

                let toSend = client.serverData.find(o => o.serverId === encodedCommand.serverId)

                //console.log("datalen: ",data);

                return toSend.write(data);

            });

        });
    }
};