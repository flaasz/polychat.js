var protobuf = require("protobufjs");


module.exports = {

    decode: function(data) {
        broadcast(data, socket);
        protobuf.load("protos/any.proto", function (err, root) {
            if (err) throw err;
        
            var wrap = root.lookupType("google.protobuf.Any");
        
            var unwrapped = wrap.decode(data);
        
            protobuf.load("protos/polychat.proto", function (err, root) {
                if (err) throw err;
        
                let type = unwrapped.typeUrl;
        
                var pc = root.lookupType(type.split("/").pop());
        
                var decoded = pc.decode(unwrapped.value);
        
                console.log(decoded);
            });
        
        })
    
    }
}



function broadcast(message, sender) {
    clients.forEach(function (client) {
        // Don't want to send it to sender
        if (client === sender) return;
        client.write(message);
    });
    // Log it to the server output too
    //process.stdout.write(message)
}