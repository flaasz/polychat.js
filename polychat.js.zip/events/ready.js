module.exports = {
	name: 'ready',
	once: true,
	execute(client) {
		console.log(`Ready! Logged in as ${client.user.tag}`);
        const channel = client.channels.cache.get('1022517180107067484');
        try {
            const webhooks = await channel.fetchWebhooks();
            const webhook = webhooks.find(wh => wh.token);
    
            if (!webhook) {
                return console.log('No webhook was found that I can use!');
            }
    
            await webhook.send({
                content: 'Webhook test',
                username: 'some-username',
                avatarURL: 'https://i.imgur.com/AfFp7pu.png',
                embeds: [embed],
            });
        } catch (error) {
            console.error('Error trying to send: ', error);
        }
    
	},
};